const express = require('express');
const multer = require('multer');
const path = require('path');
const { exec } = require('child_process');
const app = express();
const port = 3000;

// Configure storage for file uploads
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'uploads/');
    },
    filename: (req, file, cb) => {
        cb(null, file.originalname);
    }
});
const upload = multer({ storage: storage });

app.use(express.static(path.join(__dirname)));

// Serve the index.html file
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

// Handle file upload with error handling
app.post('/upload', upload.single('csvFile'), (req, res) => {
    console.log('Upload endpoint hit');
    try {
        if (req.file) {
            console.log('File saved at:', req.file.path);
            res.json({ status: 'File uploaded successfully' });
        } else {
            throw new Error('File not provided');
        }
    } catch (error) {
        console.error('Upload error:', error.message);
        res.status(500).json({ status: 'Error uploading file.', error: error.message });
    }
});

// Run LinkedIn Scraper logic
app.post('/runLinkedInScraper', (req, res) => {
    console.log('Run LinkedIn Scraper endpoint hit');
    // Replace 'your_script.py' with the path to your Python script
    exec('python script.py', (error, stdout, stderr) => {
        if (error) {
            console.error(`Error executing Python script: ${error.message}`);
            return res.status(500).json({ status: 'Error executing scraper.', error: error.message });
        }
        if (stderr) {
            console.error(`Script stderr: ${stderr}`);
            return res.status(500).json({ status: 'Script error.', error: stderr });
        }
        console.log(`Script stdout: ${stdout}`);
        res.json({ status: 'LinkedIn Scraper executed successfully', result: stdout });
    });
});

// Global error handling
app.use((err, req, res, next) => {
    console.error('Unhandled error:', err.message);
    res.status(500).send('Internal Server Error');
});

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
