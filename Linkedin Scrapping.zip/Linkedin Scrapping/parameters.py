# search query 
# enter key word as per your choice
search_query = 'linkedin.com vishwakarma institute of technology,pune  '    


# file were scraped profile information will be stored  
file_name = 'results_file.csv'

# login credentials
linkedin_username = 'rautrohit2763@gmail.com'
linkedin_password = 'I@mrohit@2'