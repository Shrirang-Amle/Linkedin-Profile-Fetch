from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import csv
import parameters
import time
import pandas as pd
from scrapy.selector import Selector
import random

# Define the output CSV writer
output_file = open('result.csv', 'w', newline='', encoding='utf-8')
writer = csv.writer(output_file)
header = ['Name', 'Job Title', 'Company / College', 'Location', 'URL']
writer.writerow(header)

# Configure Chrome service and options
cService = ChromeService(executable_path='C:\\Shrirang\\New Volume B\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe')
chrome_options = webdriver.ChromeOptions()
chrome_options.add_argument("--disable-infobars")
chrome_options.add_experimental_option("excludeSwitches", ['enable-automation'])
chrome_options.add_experimental_option("excludeSwitches", ["enable-logging"])
chrome_options.add_argument("--use-subprocess")
driver = webdriver.Chrome(service=cService, options=chrome_options)

# Navigate to LinkedIn
driver.get('https://www.linkedin.com/login')

try:
    # Login process
    username = WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.ID, "username")))
    username.send_keys(parameters.linkedin_username)
    password = WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.ID, "password")))
    password.send_keys(parameters.linkedin_password)
    sign_in_button = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.XPATH, '//*[@type="submit"]')))
    sign_in_button.click()

except Exception as e:
    print("Error: Unable to login.")
    print(e)
    driver.quit()
    output_file.close()
    exit(1)

time.sleep(20)

# Load the Excel file into a DataFrame
file_path = 'uploads\\Student_data.csv'
df = pd.read_csv(file_path)

# Function to check for CAPTCHA
def is_captcha_present():
    try:
        captcha_element = WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@id="recaptcha"]')))
        return True
    except Exception:
        return False

# Function to extract profile data
def extract_profile_data(sel):
    try:
        name = sel.xpath('//*[contains(@class,"text-heading-xlarge")]/text()').extract_first()
        if name:
            name = name.strip()
        else:
            name = "Data Found"

        linkedin_url = driver.current_url
        company = sel.xpath('//div[contains(@style, "-webkit-line-clamp:2;")]/text()').get()
        if company:
            company = company.strip()
        else:
            company = ""

        job_title = sel.xpath('//div[@class="text-body-medium break-words"]/text()').get()
        if job_title:
            job_title = job_title.strip()
        else:
            job_title = ""

        location = sel.xpath('//span[@class="text-body-small inline t-black--light break-words"]/text()').get()
        if location:
            location = location.strip()
        else:
            location = ""

        return name, job_title, company, location, linkedin_url

    except Exception as e:
        print(f"Error while extracting profile data: {e}")
        return None

# Iterate over names and scrape data
for name in df['Name']:
    driver.get('https://www.google.com')
    search_query = WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.NAME, 'q')))
    search_query.send_keys(parameters.search_query + name)
    search_query.send_keys(Keys.RETURN)

    while is_captcha_present():
        time.sleep(2)

    time.sleep(random.uniform(2, 5))  # Randomized sleep to avoid detection

    link_elements = driver.find_elements(By.XPATH, '//a[@jsname="UWckNb"]')
    linkedin_urls = []

    for link in link_elements:
        href = link.get_attribute("href")
        name_parts = name.split()
        first_name = name_parts[0]
        last_name = name_parts[-1]

        if first_name.lower() in href and last_name.lower() in href:
            if 'post' not in href:
                linkedin_urls.append(href)

    time.sleep(random.uniform(0.5, 1))

    profile_found = False

    # Scrape the LinkedIn profile data
    for linkedin_url in linkedin_urls:
        driver.get(linkedin_url)
        time.sleep(random.uniform(2, 5))

        sel = Selector(text=driver.page_source)

        # Extract profile data
        profile_data = extract_profile_data(sel)
        if profile_data:
            name, job_title, company, location, linkedin_url = profile_data

            # Check if company is not empty and matches 'Vishwakarma Institute'
            if company and 'Vishwakarma Institute' in company:
                writer.writerow([name, job_title, company, location, linkedin_url])
                print(f"Record saved for {name}")
                profile_found = True
                break

    if not profile_found:
        writer.writerow([name, "Record not found", "Record not found", "Record not found", "Record not found"])
        print(f"Record not found for {name}")

driver.quit()
output_file.close()
